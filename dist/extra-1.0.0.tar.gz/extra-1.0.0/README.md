<p>
              _                 _     _        _____        _           _____ _                   _                       
     /\      | |               | |   | |      |  __ \      | |         / ____| |                 | |                      
    /  \   __| | ___  _ __ __ _| |__ | | ___  | |  | | __ _| |_ __ _  | (___ | |_ _ __ _   _  ___| |_ _   _ _ __ ___  ___ 
   / /\ \ / _` |/ _ \| '__/ _` | '_ \| |/ _ \ | |  | |/ _` | __/ _` |  \___ \| __| '__| | | |/ __| __| | | | '__/ _ \/ __|
  / ____ \ (_| | (_) | | | (_| | |_) | |  __/ | |__| | (_| | || (_| |  ____) | |_| |  | |_| | (__| |_| |_| | | |  __/\__ \
 /_/    \_\__,_|\___/|_|  \__,_|_.__/|_|\___| |_____/ \__,_|\__\__,_| |_____/ \__|_|   \__,_|\___|\__|\__,_|_|  \___||___/
                                                                                                                          
<\p>                                                                                                                       

This Repository includes the Basic Data Structures written in Python. These Basic Data Structures are:
  * Linked List
    * Linked List
    * Double Linked List.
    * Circular Linked List.
  * Stack and Queues
    * Stack.
    * Queue.
    * Double-ended Queue (Dequeue).
    * Priority Queue.
  * Tree
    * Binary Tree.
    * Binary Search Tree (BST).


## Restrictions

I have put some restrictions when creating these basic data structures and they are:

- Using only built-in functions and operators... Which means that these basic data structures doesn't have any dependencies or use any other library outside python.


